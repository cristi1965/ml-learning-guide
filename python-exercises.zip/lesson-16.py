# 计算留出数据的正确率
def accuracy(predicted, actual):
    # TODO: 计算留出数据的正确率
    return None

assert accuracy([1,0,1],[1,1,1])==2/3
assert accuracy([0,1],[0,1])==1
print("所有检查通过")
