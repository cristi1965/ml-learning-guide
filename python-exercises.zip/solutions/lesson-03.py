# 计算二分查找下一次猜测
def midpoint(low, high):
    return (low+high)/2

assert midpoint(0,10)==5
assert midpoint(0,5)==2.5
print("所有检查通过")
