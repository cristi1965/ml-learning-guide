# 写出负数归零规则
def relu(x):
    return max(0,x)

assert relu(-2)==0
assert relu(1)==1
assert relu(0)==0
print("所有检查通过")
