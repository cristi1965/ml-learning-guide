# 完成一维 K 近邻分类。此处只练核心步骤；原仓库依赖不在浏览器运行。
def knn(points, labels, query, k):
    if not 1<=k<=len(points):
        raise ValueError("invalid k")
    indices=sorted(range(len(points)),key=lambda i:(abs(points[i]-query),i))[:k]
    votes=[labels[i] for i in indices]
    return min(set(votes),key=lambda label:(-votes.count(label),label))

assert knn([0,2,5],["A","A","B"],4,1)=="B"
assert knn([0,2,5],["A","A","B"],4,3)=="A"
assert knn([0,2],["B","A"],1,2)=="A"
print("所有检查通过")
