# 教学计算（Python 标准库，不运行上游完整模型）：实现残差加法后的ReLU并验证负值边界。
def residual_relu(x, correction):
    return [max(0,a+b) for a,b in zip(x,correction)]

assert residual_relu([2,-1],[-0.5,0.2]) == [1.5,0]
assert residual_relu([1,3],[0,0]) == [1,3]
print("所有检查通过")
