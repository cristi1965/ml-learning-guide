# 教学计算（Python 标准库，不运行上游完整模型）：用一组特征计算 LayerNorm，再解释 Dropout 的保留缩放。
def normalize(values, eps=1e-5):
    # TODO: 补齐本课的教学计算
    return [0 for _ in values]

out=normalize([2,4])
assert len(out)==2, "必须为每个输入返回一个结果"
assert all(abs(a-b)<1e-5 for a,b in zip(out,[-1,1]))
assert normalize([5,5]) == [0,0]
third=normalize([1,2,3])
assert len(third)==3 and abs(sum(third))<1e-8 and third[0]<0<third[2]
print("所有检查通过")
