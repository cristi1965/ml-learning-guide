# 实现单样本 hinge loss。此处只练核心步骤；原仓库依赖不在浏览器运行。
def hinge(label, score):
    # TODO：替换占位返回值
    return 0

assert abs(hinge(1,0.2)-0.8)<1e-9
assert hinge(-1,-2)==0
assert hinge(1,-2)==3
assert hinge(1,1)==0
print("所有检查通过")
