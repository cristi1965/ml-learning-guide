# 加入固定配送费
def predict(x, w, b):
    return x*w+b

assert predict(2,3,2)==8
assert predict(0,3,2)==2
print("所有检查通过")
