# 加入固定配送费
def predict(x, w, b):
    # TODO: 加入固定配送费
    return None

assert predict(2,3,2)==8
assert predict(0,3,2)==2
print("所有检查通过")
