# 教学计算（Python 标准库，不运行上游完整模型）：构建含固定种子、数据指纹和独立测试准确率的微型复现记录。
def report(labels, predictions, seed):
    import random, hashlib, json
    order = list(range(len(labels)))
    random.Random(seed).shuffle(order)
    digest = hashlib.sha256(json.dumps(labels).encode()).hexdigest()
    accuracy = sum(a==b for a,b in zip(labels,predictions))/len(labels)
    return {"order":order,"data_hash":digest,"accuracy":accuracy}

import hashlib, json
labels=[0,1,1,0]
a=report(labels,[0,1,0,0],42)
assert a["accuracy"] == 0.75
assert a == report(labels,[0,1,0,0],42)
assert a["order"] == [2,1,3,0], "seed=42时四项排列应可复现"
assert a["data_hash"] == hashlib.sha256(json.dumps(labels).encode()).hexdigest()
b=report(labels,[0,1,1,0],7)
assert b["order"] == [3,1,0,2], "应真正使用传入的种子"
assert b["accuracy"] == 1 and b["data_hash"] == a["data_hash"]
c=report([1,0],[1,0],7)
assert sorted(c["order"]) == [0,1]
assert c["data_hash"] != a["data_hash"]
print("所有检查通过")
