# 教学计算（Python 标准库，不运行上游完整模型）：算出 sigmoid + MSE 的单样本权重和偏置梯度。
def gradients(x, w, b, y):
    import math
    p = 1 / (1 + math.exp(-(w*x+b)))
    delta = 2*(p-y)*p*(1-p)
    return delta*x, delta

assert gradients(2,0,0,1) == (-0.5,-0.25)
assert gradients(3,0,0,0) == (0.75,0.25)
import math
def loss(w,b):
    probability=1/(1+math.exp(-(w*2+b)))
    return (probability-1)**2
h=1e-5
gw,gb=gradients(2,0.4,-0.1,1)
assert abs(gw-(loss(0.4+h,-0.1)-loss(0.4-h,-0.1))/(2*h))<1e-7
assert abs(gb-(loss(0.4,-0.1+h)-loss(0.4,-0.1-h))/(2*h))<1e-7

print("所有检查通过")
