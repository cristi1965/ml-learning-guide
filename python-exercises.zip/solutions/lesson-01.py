# 预测一笔苹果订单
def price(weight, unit_price):
    return weight * unit_price

assert price(2,3)==6
assert price(0,3)==0
assert price(1.5,4)==6
print("所有检查通过")
