# 重新计算一个簇的中心
def center(points):
    # TODO: 重新计算一个簇的中心
    return None

assert center([0,2,4])==2
assert center([10,12])==11
print("所有检查通过")
