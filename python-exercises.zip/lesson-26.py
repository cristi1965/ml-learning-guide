# 计算标签集合的熵。此处只练核心步骤；原仓库依赖不在浏览器运行。
def entropy(labels):
    # TODO：替换占位返回值
    return 0

assert abs(entropy([0,0,1,1])-1)<1e-9
assert entropy([1,1,1])==0
assert entropy([])==0
assert abs(entropy([0,1,2,3])-2)<1e-9
print("所有检查通过")
