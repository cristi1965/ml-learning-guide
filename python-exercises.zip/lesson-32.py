# 计算均方误差加 L2 权重惩罚。此处只练核心步骤；原仓库依赖不在浏览器运行。
def ridge_loss(predictions, targets, weights, alpha):
    # TODO：替换占位返回值
    return 0

assert ridge_loss([1,3],[2,2],[2,-1],0.1)==1.5
assert ridge_loss([1,3],[2,2],[2,-1],0)==1
assert ridge_loss([2],[2],[0],10)==0
assert ridge_loss([2],[2],[-2],0.5)==2
print("所有检查通过")
