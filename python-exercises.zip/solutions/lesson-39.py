# 教学计算（Python 标准库，不运行上游完整模型）：计算给定门值下的LSTM细胞状态和隐藏输出。
def cell(previous, forget, incoming, candidate, output):
    import math
    c = forget*previous+incoming*candidate
    return c, output*math.tanh(c)

import math
c,h=cell(2,0.5,0.25,0.8,0.5)
assert abs(c-1.2)<1e-12 and abs(h-0.5*math.tanh(1.2))<1e-12
assert cell(2,1,0,0.8,0)[0] == 2
print("所有检查通过")
