# 教学计算（Python 标准库，不运行上游完整模型）：计算2×2窗口与卷积核的逐元素乘积和。
def window_dot(window, kernel):
    # TODO: 补齐本课的教学计算
    return 0

assert window_dot([[1,2],[3,4]],[[1,0],[-1,1]]) == 2
assert window_dot([[2,2],[2,2]],[[1,1],[1,1]]) == 8
print("所有检查通过")
