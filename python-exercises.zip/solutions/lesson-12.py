# 模拟一个记忆更新
def memory(old, keep, candidate, write):
    return old*keep+candidate*write

assert memory(10,.2,4,.5)==4
assert memory(10,1,4,0)==10
print("所有检查通过")
