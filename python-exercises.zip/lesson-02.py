# 完成一次梯度更新
def update(w, rate):
    # TODO: 完成一次梯度更新
    return None

assert abs(update(2,.1)-2.8)<1e-9
assert abs(update(4,.1)-3.2)<1e-9
print("所有检查通过")
