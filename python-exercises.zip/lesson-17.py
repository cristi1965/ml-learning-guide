# 把 6 个数按指定行列重新排好。此处只练核心步骤；原仓库依赖不在浏览器运行。
def reshape(values, rows, cols):
    # TODO：替换占位返回值
    return 0

assert reshape([1,2,3,4,5,6],2,3)==[[1,2,3],[4,5,6]]
assert reshape([],0,3)==[]
try:
    reshape([1,2],2,2)
    assert False, "必须拒绝元素数不符"
except ValueError:
    pass
print("所有检查通过")
