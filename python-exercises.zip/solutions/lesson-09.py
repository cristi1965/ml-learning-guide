# 手算加法再乘法的梯度
def grads(a, b, c):
    return (c,c,a+b)

assert grads(2,3,4)==(4,4,5)
assert grads(2,3,6)==(6,6,5)
print("所有检查通过")
