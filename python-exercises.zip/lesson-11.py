# 合并残差与主路结果
def residual(x, change):
    # TODO: 合并残差与主路结果
    return None

assert residual([1,2],[.5,-1])==[1.5,1]
assert residual([0],[3])==[3]
print("所有检查通过")
