# 教学计算（Python 标准库，不运行上游完整模型）：对分数做稳定softmax并加权求值。
def attend(scores, values):
    import math
    peak = max(scores)
    weights = [math.exp(s-peak) for s in scores]
    return sum(w*v for w,v in zip(weights,values))/sum(weights)

import math
assert abs(attend([0,math.log(3)],[2,6])-5)<1e-12
assert attend([1000,1000],[2,4]) == 3
print("所有检查通过")
