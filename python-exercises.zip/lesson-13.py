# 算一次注意力加权汇总
def attend(values, weights):
    # TODO: 算一次注意力加权汇总
    return None

assert attend([10,20],[.25,.75])==17.5
assert attend([10,20],[1,0])==10
print("所有检查通过")
