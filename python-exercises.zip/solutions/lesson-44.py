# 教学计算（Python 标准库，不运行上游完整模型）：计算全连接网络参数数目，并核对输入输出尺寸。
def parameter_count(sizes):
    return sum(a*b+b for a,b in zip(sizes,sizes[1:]))

assert parameter_count([784,30,10]) == 23860
assert parameter_count([2,3,1]) == 13
print("所有检查通过")
