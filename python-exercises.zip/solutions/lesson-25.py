# 执行一维 KMeans 的一轮分配与更新。此处只练核心步骤；原仓库依赖不在浏览器运行。
def kmeans_step(points, centers):
    groups=[[] for _ in centers]
    for p in points:
        i=min(range(len(centers)),key=lambda i:abs(p-centers[i]))
        groups[i].append(p)
    return [sum(g)/len(g) if g else centers[i] for i,g in enumerate(groups)]

assert kmeans_step([0,2,8,10],[0,10])==[1,9]
assert kmeans_step([1,2],[0,100])==[1.5,100]
assert kmeans_step([],[3,9])==[3,9]
print("所有检查通过")
