# 计算二元特征的拉普拉斯平滑概率。此处只练核心步骤；原仓库依赖不在浏览器运行。
def smooth_probability(present, total, alpha=1.0):
    # TODO：替换占位返回值
    return 0

assert smooth_probability(0,3)==0.2
assert smooth_probability(3,3)==0.8
assert smooth_probability(0,0)==0.5
assert smooth_probability(1,4,2)==0.375
print("所有检查通过")
