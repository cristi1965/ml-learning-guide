# 教学计算（Python 标准库，不运行上游完整模型）：计算真实下一token概率的平均负对数似然。
def next_token_loss(probabilities):
    # TODO: 补齐本课的教学计算
    return 0

import math
assert abs(next_token_loss([0.5,0.25])-1.5*math.log(2))<1e-12
assert next_token_loss([1,1]) == 0
print("所有检查通过")
