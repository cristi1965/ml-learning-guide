# 计算召回率
def recall(tp, fn):
    # TODO: 计算召回率
    return None

assert recall(3,1)==.75
assert recall(0,4)==0
assert recall(0,0)==0
print("所有检查通过")
