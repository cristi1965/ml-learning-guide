# 计算矩阵每行与向量的点积。此处只练核心步骤；原仓库依赖不在浏览器运行。
def matvec(matrix, vector):
    # TODO：替换占位返回值
    return 0

assert matvec([[1,2],[3,4]],[10,20])==[50,110]
assert matvec([],[])==-1
assert matvec([[1,2]],[1])==-1
print("所有检查通过")
