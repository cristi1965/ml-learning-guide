# 合并同一节点的多路梯度
def accumulate(contributions):
    return sum(contributions)

assert accumulate([2,3])==5
assert accumulate([4,-4])==0
assert accumulate([])==0
print("所有检查通过")
