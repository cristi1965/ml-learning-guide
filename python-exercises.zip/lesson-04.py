# 把两种商品的费用相加
def dot(a, b):
    # TODO: 把两种商品的费用相加
    return None

assert dot([2,1],[3,4])==10
assert dot([0,0],[3,4])==0
assert dot([1,-1],[2,3])==-1
print("所有检查通过")
