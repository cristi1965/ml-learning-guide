# 计算召回率
def recall(tp, fn):
    return tp/(tp+fn) if tp+fn else 0.0

assert recall(3,1)==.75
assert recall(0,4)==0
assert recall(0,0)==0
print("所有检查通过")
