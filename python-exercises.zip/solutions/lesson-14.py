# 给字符向量加上位置信息
def add_position(token, position):
    return [a+b for a,b in zip(token,position)]

assert add_position([1,2],[.1,.2])==[1.1,2.2]
assert add_position([0,0],[3,4])==[3,4]
print("所有检查通过")
