# 用中心差分估计平方函数的斜率。此处只练核心步骤；原仓库依赖不在浏览器运行。
def central_diff(f, x, h=0.001):
    if h<=0:
        raise ValueError("h must be positive")
    return (f(x+h)-f(x-h))/(2*h)

assert abs(central_diff(lambda x:x*x,3)-6)<1e-6
assert abs(central_diff(lambda x:x*x,-2)+4)<1e-6
assert abs(central_diff(lambda x:7,0))<1e-6
assert abs(central_diff(lambda x:x**3,2)-12)<1e-4
print("所有检查通过")
