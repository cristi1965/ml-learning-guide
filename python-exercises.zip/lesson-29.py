# 用给定训练集范围做 min-max 缩放。此处只练核心步骤；原仓库依赖不在浏览器运行。
def minmax(values, train_min, train_max):
    # TODO：替换占位返回值
    return 0

assert minmax([10,20,30],10,30)==[0,0.5,1]
assert minmax([40],10,30)==[1.5]
assert minmax([5,5],5,5)==[0,0]
assert minmax([],0,1)==[]
print("所有检查通过")
