# 计算留出数据的正确率
def accuracy(predicted, actual):
    return sum(a==b for a,b in zip(predicted,actual))/len(actual)

assert accuracy([1,0,1],[1,1,1])==2/3
assert accuracy([0,1],[0,1])==1
print("所有检查通过")
