# 教学计算（Python 标准库，不运行上游完整模型）：实现从零状态出发的 Adam 第一步。
def adam_first(parameter, gradient, rate):
    # TODO: 补齐本课的教学计算
    return 0

assert abs(adam_first(1,2,0.1)-0.9)<1e-8
assert abs(adam_first(1,-2,0.1)-1.1)<1e-8
print("所有检查通过")
