# 按真实与预测标签统计 TN、FP、FN、TP。此处只练核心步骤；原仓库依赖不在浏览器运行。
def confusion(pairs):
    result=[[0,0],[0,0]]
    for pred,true in pairs:
        result[true][pred]+=1
    return result

assert confusion([(0,0),(1,0),(0,1),(1,1)])==[[1,1],[1,1]]
assert confusion([(0,1),(0,1),(1,1)])==[[0,0],[2,1]]
assert confusion([])==[[0,0],[0,0]]
print("所有检查通过")
