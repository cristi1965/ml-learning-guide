# 教学计算（Python 标准库，不运行上游完整模型）：实现一次误分类驱动的感知机参数更新。
def perceptron_step(weights, bias, x, target, prediction, rate):
    # TODO: 补齐本课的教学计算
    return ([], 0)

assert perceptron_step([0,0],0,[1,2],1,0,0.1) == ([0.1,0.2],0.1)
assert perceptron_step([1,2],3,[2,4],1,1,0.1) == ([1,2],3)
print("所有检查通过")
