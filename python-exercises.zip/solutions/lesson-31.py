# 按指定测试索引拆分样本和标签。此处只练核心步骤；原仓库依赖不在浏览器运行。
def split_data(x, y, test_indices):
    selected=set(test_indices)
    train=[i for i in range(len(x)) if i not in selected]
    test=[i for i in range(len(x)) if i in selected]
    return ([x[i] for i in train],[x[i] for i in test],[y[i] for i in train],[y[i] for i in test])

assert split_data([10,20,30,40],[0,0,1,1],[1,3])==([10,30],[20,40],[0,1],[0,1])
assert split_data([5],[9],[])==([5],[],[9],[])
assert split_data([5],[9],[0])==([],[5],[],[9])
print("所有检查通过")
