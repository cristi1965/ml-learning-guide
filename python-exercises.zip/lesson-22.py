# 实现无截距一元回归的一次梯度更新。此处只练核心步骤；原仓库依赖不在浏览器运行。
def step(x, y, weight, rate):
    # TODO：替换占位返回值
    return 0

assert abs(step([1,2],[2,4],0,0.1)-0.5)<1e-9
assert step([1,2],[2,4],2,0.1)==2
assert step([0],[8],3,0.2)==3
print("所有检查通过")
