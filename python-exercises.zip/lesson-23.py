# 把线性分数变成二分类标签。此处只练核心步骤；原仓库依赖不在浏览器运行。
def classify(x, weights, bias):
    # TODO：替换占位返回值
    return 0

assert classify([1,1],[1,1],0)==1
assert classify([-1,-1],[1,1],0)==0
assert classify([0],[1],0)==1
assert classify([-1000],[1],0)==0
print("所有检查通过")
