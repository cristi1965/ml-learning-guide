# 教学计算（Python 标准库，不运行上游完整模型）：生成允许关注当前位置及过去的因果掩码。
def causal(length):
    # TODO: 补齐本课的教学计算
    return []

assert causal(3) == [[True,False,False],[True,True,False],[True,True,True]]
assert causal(1) == [[True]]
print("所有检查通过")
