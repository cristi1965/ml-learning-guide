# 把两种商品的费用相加
def dot(a, b):
    return sum(x*y for x,y in zip(a,b))

assert dot([2,1],[3,4])==10
assert dot([0,0],[3,4])==0
assert dot([1,-1],[2,3])==-1
print("所有检查通过")
