# 给矩阵每行加上同一偏置向量。此处只练核心步骤；原仓库依赖不在浏览器运行。
def add_bias(matrix, bias):
    # TODO：替换占位返回值
    return 0

assert add_bias([[4,5,6],[7,8,9]],[1,2,3])==[[5,7,9],[8,10,12]]
assert add_bias([], [1])==[]
assert add_bias([[-1,2]],[1,-2])==[[0,0]]
print("所有检查通过")
