# 合并残差与主路结果
def residual(x, change):
    return [a+b for a,b in zip(x,change)]

assert residual([1,2],[.5,-1])==[1.5,1]
assert residual([0],[3])==[3]
print("所有检查通过")
