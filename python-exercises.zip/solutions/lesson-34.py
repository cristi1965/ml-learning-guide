# 教学计算（Python 标准库，不运行上游完整模型）：实现从零状态出发的 Adam 第一步。
def adam_first(parameter, gradient, rate):
    m = 0.1*gradient
    v = 0.001*gradient**2
    return parameter-rate*(m/0.1)/((v/0.001)**0.5+1e-8)

assert abs(adam_first(1,2,0.1)-0.9)<1e-8
assert abs(adam_first(1,-2,0.1)-1.1)<1e-8
print("所有检查通过")
