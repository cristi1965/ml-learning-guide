# 算一次注意力加权汇总
def attend(values, weights):
    return sum(v*w for v,w in zip(values,weights))

assert attend([10,20],[.25,.75])==17.5
assert attend([10,20],[1,0])==10
print("所有检查通过")
