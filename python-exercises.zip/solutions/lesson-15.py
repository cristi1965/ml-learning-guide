# 构造下一字符训练样本
def shift(tokens):
    return (tokens[:-1], tokens[1:])

assert shift([0,1,2,1,0])==([0,1,2,1],[1,2,1,0])
assert shift([0,3,0])==([0,3],[3,0])
print("所有检查通过")
