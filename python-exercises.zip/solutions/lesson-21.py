# 计算两个特征的样本协方差。此处只练核心步骤；原仓库依赖不在浏览器运行。
def covariance(x, y):
    if len(x)!=len(y) or len(x)<2:
        raise ValueError("need paired samples")
    mx, my = sum(x)/len(x), sum(y)/len(y)
    return sum((a-mx)*(b-my) for a,b in zip(x,y))/(len(x)-1)

assert covariance([1,2,3],[2,4,6])==2
assert covariance([1,2,3],[6,4,2])==-2
assert covariance([2,2],[1,5])==0
print("所有检查通过")
