# 教学计算（Python 标准库，不运行上游完整模型）：查token向量并逐位置加上位置向量。
def embed(tokens, table, positions):
    # TODO: 补齐本课的教学计算
    return []

assert embed([1,1],[[0,0],[2,3]],[[0,1],[1,0]]) == [[2,4],[3,3]]
assert embed([0],[[4,5]],[[0,0]]) == [[4,5]]
print("所有检查通过")
