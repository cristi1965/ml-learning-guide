# 把线性分数变成二分类标签。此处只练核心步骤；原仓库依赖不在浏览器运行。
def classify(x, weights, bias):
    import math
    z=sum(a*b for a,b in zip(x,weights))+bias
    p=1/(1+math.exp(-z)) if z>=0 else math.exp(z)/(1+math.exp(z))
    return int(p>=0.5)

assert classify([1,1],[1,1],0)==1
assert classify([-1,-1],[1,1],0)==0
assert classify([0],[1],0)==1
assert classify([-1000],[1],0)==0
print("所有检查通过")
