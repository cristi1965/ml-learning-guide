# 实现单样本 hinge loss。此处只练核心步骤；原仓库依赖不在浏览器运行。
def hinge(label, score):
    if label not in (-1,1):
        raise ValueError("labels must be -1 or 1")
    return max(0.0,1-label*score)

assert abs(hinge(1,0.2)-0.8)<1e-9
assert hinge(-1,-2)==0
assert hinge(1,-2)==3
assert hinge(1,1)==0
print("所有检查通过")
