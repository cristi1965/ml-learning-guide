# 教学计算（Python 标准库，不运行上游完整模型）：实现单维递归状态更新。
def recurrent(xs, wx=1, wh=1, bias=0):
    import math
    h = 0.0
    for x in xs:
        h = math.tanh(wx*x+wh*h+bias)
    return h

import math
assert abs(recurrent([1,0])-math.tanh(math.tanh(1)))<1e-12
assert recurrent([0,0]) == 0
print("所有检查通过")
