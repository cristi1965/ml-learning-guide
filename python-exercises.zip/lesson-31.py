# 按指定测试索引拆分样本和标签。此处只练核心步骤；原仓库依赖不在浏览器运行。
def split_data(x, y, test_indices):
    # TODO：替换占位返回值
    return 0

assert split_data([10,20,30,40],[0,0,1,1],[1,3])==([10,30],[20,40],[0,1],[0,1])
assert split_data([5],[9],[])==([5],[],[9],[])
assert split_data([5],[9],[0])==([],[5],[],[9])
print("所有检查通过")
