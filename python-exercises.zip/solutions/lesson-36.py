# 教学计算（Python 标准库，不运行上游完整模型）：按每轮样本量计算独立的平均损失。
def epoch_means(epochs):
    return [sum(loss*n for loss,n in batches)/sum(n for _,n in batches) for batches in epochs]

assert epoch_means([[(2,2),(8,1)],[(1,2)]]) == [4,1]
assert epoch_means([[(3,1),(5,1)]]) == [4]
print("所有检查通过")
