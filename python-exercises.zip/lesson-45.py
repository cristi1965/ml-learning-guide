# 教学计算（Python 标准库，不运行上游完整模型）：在相同logits上核对索引标签与one-hot交叉熵一致。
def classification_loss(logits, target):
    # TODO: 补齐本课的教学计算
    return 0

import math
assert abs(classification_loss([0,math.log(3)],1)+math.log(0.75))<1e-12
assert abs(classification_loss([1000,1000],0)-math.log(2))<1e-10
assert abs(classification_loss([0,math.log(3)],[0,1])-classification_loss([0,math.log(3)],1))<1e-12
assert abs(classification_loss([1000,1000],[1,0])-math.log(2))<1e-10
print("所有检查通过")
